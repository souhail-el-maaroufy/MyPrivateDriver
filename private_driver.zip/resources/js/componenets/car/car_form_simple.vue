<template>
       <li class="car">
                    <a id="my_car_13" title="Van: Ssangyoung" gallery_type="simple" carid="13" personnes="6"
                        price_airport="30" bags="7" carcode="sy" price_min="19" order="3"
                        price_day="140" price_half="80" price_km="1.1" hour_rate="12" available="1"
                        carname="Van: Ssangyoung">
                        <img src="https://www.allomycab.ma/images/car_sy.jpg" width="80" alt="Van: Ssangyoung" />
                        <span> Van: Ssangyoung </span>
                        <div style="float:right; padding: 1.5% 1%;">
                            <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x6
                                </span></div>
                            <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x7
                                </span></div>
                            <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                        </div>
                    </a>
                </li>
</template>
<script setup>

import { ref } from "vue";


</script>