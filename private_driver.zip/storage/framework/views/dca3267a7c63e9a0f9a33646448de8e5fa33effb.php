<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <input type="range" class="form-range" <?php echo e($attributes); ?>>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\orchid-project\vendor\orchid\platform\resources\views/fields/range.blade.php ENDPATH**/ ?>