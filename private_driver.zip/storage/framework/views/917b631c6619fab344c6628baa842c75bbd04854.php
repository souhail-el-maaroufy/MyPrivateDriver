<div class="rounded bg-white mb-3 p-3">
    <div class="border-dashed d-flex align-items-center w-100 rounded overflow-hidden" style="min-height: 250px;">
        <h2 class="text-muted center fw-light">Dummy <small class="d-block text-center"><?php echo e(Str::random(8)); ?></small></h2>
    </div>
</div>
<?php /**PATH C:\laragon\www\orchid-project\vendor\orchid\platform\resources\views/dummy/block.blade.php ENDPATH**/ ?>