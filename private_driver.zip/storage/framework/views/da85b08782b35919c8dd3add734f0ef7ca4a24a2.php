<div class="nav-tabs-alt">
    <ul class="nav nav-tabs nav-tabs-scroll-bar" role="tablist">
        <?php echo $navigations; ?>

    </ul>
</div>
<?php /**PATH C:\laragon\www\orchid-project\vendor\orchid\platform\resources\views/layouts/tabMenu.blade.php ENDPATH**/ ?>