<footer>
    <div id="gtco-portfolio">
        <div class="gtco-container">
            
            <div class="row">
                <div style="padding: 30px;" class="col-md-4">
                    <div>
                        <img class="logo-footer" src="<?php echo e(asset('images/gallery/new/logo.png')); ?>" alt="">
                        <h3 class="white-text">Private Driver Car</h3>
                    </div>
                    <div class="logo-footer-text">
                        <p>We provide professional chauffeur and car rental services in Marrakech and throughout Morocco. Our focus on hybrid and private drivers ensures a high-quality, Made in Morocco product, serving professionals, tourists, and individuals as an alternative to traditional taxis.</p>
                    </div>
                </div>
                <div style="padding: 30px;" class="col-md-4">
                    <h3 class="white-text">Our services</h3>
                    <ul class="our-services-footer">
                        <li>
                            <a href="#">Easy Online Booking</a>
                        </li>
                        <li>
                            <a href="#">Professional Drivers</a>
                        </li>
                        <li>
                            <a href="#">Variety of car Brands </a>
                        </li>
                        <li>
                            <a href="#">Long Term Rates</a>
                        </li>
                    </ul>
                </div>
                <div style="padding: 30px;" class="col-md-4">
                    <h3 class="white-text">Contact us</h3>
                    <div class="countact-us-footer">
                        <span><i class="fa-solid fa-envelope"></i> Email : private_driver@gmail.com</span>
                    </div>
                    <div class="countact-us-footer">
                        <span><i class="fa-solid fa-location-dot"></i> Adresse : Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Nihil, ipsam dolores, adipisci .</span>
                    </div>
                    <div class="countact-us-footer">
                        <span><i class="fa-solid fa-phone"></i> Phone : +212 787 543 213</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
    
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center" style="background: #333;color:white;">
                <p>Copyright &copy; 2023 - Private Driver Car , Tous droits réservés.</p>
        </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\MyPrivateDriver\resources\views/frontend/partials/footer.blade.php ENDPATH**/ ?>