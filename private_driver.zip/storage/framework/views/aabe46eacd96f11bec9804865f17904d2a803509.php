<form autocomplete="off" id="simple_form" class="form-horizontal main-form" method="post"
    action="<?php echo e(route('reservation_details')); ?>">
    <?php echo csrf_field(); ?>
    
    <input type="hidden" name="depart_latlng" value="0">
    <input type="hidden" name="destination_latlng" value="0">
    <input type="hidden" name="type" value="SIMPLE">
    <input type="hidden" class="is_airport" name="is_airport" value="0">
    <input type="hidden" name="date_reservation" class="date_reservation" value="">
    <fieldset>
        <div class="time-choices col-md-12">
            <div class="choice later active">Later</div>
            <div class="choice now" data-now="now">Now</div>
        </div>
        <!-- Reservation Date Picker -->
        <div class="form-group col-md-12 date-res">
            <label class='date_hours' for="">Date & Hour of
                departure (Morocco) :&nbsp; <i class="ti-calendar"></i>&nbsp;<i class="ti-timer"></i>
                <div class="am-pm"></div>
            </label>

        </div>
        <div class="date-res">
            <div class="col-md-7 form-group">
                <div class="reportrange pull-right  form-control">
                    <i class="ti-calendar"></i>&nbsp;
                    <span></span> <b class="caret"></b>
                </div>
            </div>
            <div class="col-md-1">
                <div class="form-group"><i class="ti-timer"></i>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">

                    <select name="hours" class="form-control hours">
                        <option value="0"> 00</option>
                        <option value="1"> 01</option>
                        <option value="2"> 02</option>
                        <option value="3"> 03</option>
                        <option value="4"> 04</option>
                        <option value="5"> 05</option>
                        <option value="6"> 06</option>
                        <option value="7"> 07</option>
                        <option value="8"> 08</option>
                        <option value="9"> 09</option>
                        <option value="10"> 10</option>
                        <option value="11"> 11</option>
                        <option value="12"> 12</option>
                        <option value="13"> 13</option>
                        <option value="14"> 14</option>
                        <option value="15"> 15</option>
                        <option value="16"> 16</option>
                        <option value="17"> 17</option>
                        <option value="18"> 18</option>
                        <option value="19"> 19</option>
                        <option value="20"> 20</option>
                        <option value="21"> 21</option>
                        <option value="22"> 22</option>
                        <option value="23"> 23</option>

                    </select>
                </div>
            </div>
            <div class="col-md-1">
                <div class="form-group">:
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <select name="minutes" class="form-control minutes">
                        <option value="0"> 00</option>
                        <option value="5"> 05</option>
                        <option value="10"> 10</option>
                        <option value="15"> 15</option>
                        <option value="20"> 20</option>
                        <option value="25"> 25</option>
                        <option value="30"> 30</option>
                        <option value="35"> 35</option>
                        <option value="40"> 40</option>
                        <option value="45"> 45</option>
                        <option value="50"> 50</option>
                        <option value="55"> 55</option>
                    </select>
                </div>
            </div>
        </div>
        <!-- End of Reservation Date Picker -->

        <div class="form-group col-md-12 cars" style="display:none;">
            <input type="hidden" class="car_model" name="car_model" value="0" personnes="" bags=""
                carcode="" carname="" price="0" />
            <button id="choose_car_simple" type="button" class="simple_form btn btn-default dropdown-toggle"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="">
                <span class="car_chosen_title">You have chosen : </span>
                <span class="car_chosen" style="color:#334e86;">Choose
                    your car</span>
                <img class="select_arrows" alt="select arrows"
                    src="https://www.allomycab.ma/images/arrow-select.svg"></button>

            <ul class="dropdown-menu">

                <li class="dropdown-header">Economy</li>

                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="car">
                        <a id="my_car_<?php echo e($car->id); ?>" carid="<?php echo e($car->id); ?>" title="<?php echo e($car->name); ?>" gallery_type="simple"
                            personnes="<?php echo e($car->personne); ?>" price_airport="<?php echo e($car->price_airport); ?>"
                            bags="<?php echo e($car->bags); ?>"
                            carcode="<?php echo e(asset('storage/2022/10/09/fef798bc914b3dcd06bebe6e04c794c435b8d687.png')); ?>"
                            price_min="<?php echo e($car->price_min); ?>" order="2" price_day="<?php echo e($car->price_day); ?>"
                            price_half="<?php echo e($car->price_half); ?>" price_km="<?php echo e($car->price_km); ?>"
                            hour_rate="<?php echo e($car->houe_rate); ?>" available="1" carname="<?php echo e($car->name); ?>">

                            <?php
                                $car_img = $car->attachment()->get();
                            ?>
                            <img src="<?php echo e(asset('storage/2022/10/09/fef798bc914b3dcd06bebe6e04c794c435b8d687.png')); ?>"
                                width="80" alt="Van: Hyundai-H1" />
                            <span> </span>
                            <div style="float:right; padding: 1.5% 1%;">
                                <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>
                                    </span></div>
                                <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>
                                    </span></div>
                                <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </ul>

        </div>

        <div class="form-group col-md-12">
            <input required autocomplete="off" style="width:88%; float:left;" type="text"
                class="form-control departSelector depart" placeholder="Departure : adress, hotel, airport..."
                name="depart" id="depart">
            <a href="" class="geolocalize-me" title="My location" id="geo_depart"><img
                    src="https://www.allomycab.ma/images/localize.svg" alt="geolocalisation" /></a>
        </div>
        <div class="form-group col-md-12">
            <input style="width:88%; float:left;" required autocomplete="off" type="text"
                class="form-control arriveeSelector destination" placeholder="Destination : adress, hotel, airport..."
                name="destination" id="destination">
            <a href="" class="geolocalize-me" title="My location" id="geo_destination"><img
                    src="https://www.allomycab.ma/images/localize.svg" alt="geolocalisation" /></a>
        </div>

        <div id="cars_prices" class="form-group col-md-12">
            <input type="hidden" class="car_model" name="car_model" value="0" personnes="" price="0"
                bags="" carcode="" carname="" />
            <ul>

            </ul>
        </div>

        <div class="form-group col-md-12 car-gallery">
            <div id="gall" class="popup-gallery"></div>
            <div id="selected_cars" class="my_selected_cars">
            </div>
        </div>

        <input type="hidden" class="data" name="data" value="0" />
        <!--
                                    <div class="form-group col-md-12 two-ways">
                                        <div class="form-error-msg"></div>
                                        <button type="button" class="btn btn-success btn-submit dif">Two ways                                    &nbsp;&nbsp;</button>
                                    </div>
                                            -->

        <div class="twoways-container closelist">
            <div class="form-group col-md-6 switcher go-switch">
                <label class="form-switch">
                    <input type="checkbox" id="twoways" name="twoways" class="twoways">
                    <i></i>
                    Two ways ? <br />
                </label>
            </div>

            <div class="form-group col-md-6 switcher back-switch">
                <label class="form-switch">
                    <input type="checkbox" id="back-switch" name="back-switch" class="twoways">
                    <i></i>
                    Date retour différente ?
                </label>
            </div>

            <div class="form-group col-md-12 waiting-hours closelist">
                <select id="waite-time" name="wait-time" class="form-control" class="waite-time">
                    <option selected value="0"> Waiting hours (
                        Optional )</option>
                    <option value="1"> 1 Hour</option>
                    <option value="2"> 2 Hours</option>
                    <option value="3"> 3 Hours</option>
                    <option value="4"> 4 Hours</option>
                    <option value="5"> 5 Hours</option>
                    <option value="6"> 6 Hours</option>
                    <option value="7"> 7 Hours</option>
                    <option value="8"> 8 Hours</option>
                </select>
            </div>



            <div class="back_date closelist">
                <!-- Reservation Date Picker -->
                <!-- <div class="form-group col-md-12 date-res">
                                    <label class='date_hours' for="">Date & Hour of departure (Morocco) :&nbsp; <i
                                            class="ti-calendar"></i>&nbsp;<i class="ti-timer"></i>  <div class="am-pm"></div></label>
                                        
                                </div> -->
                <!-- <input type="hidden" name="back_date_reservation" class="back_date_reservation" value="">
                                <div class="date-res">
                                
                                    <div class="col-md-7 form-group">
                                        <div class="reportrange pull-right  form-control">
                                            <i class="ti-calendar"></i>&nbsp;
                                            <span></span> <b class="caret"></b>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="form-group"><i class="ti-timer"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                        
                                            <select name="hours" class="form-control hours">
                                                <option value="0"> 00</option>
                                                <option value="1"> 01</option>
                                                <option value="2"> 02</option>
                                                <option value="3"> 03</option>
                                                <option value="4"> 04</option>
                                                <option value="5"> 05</option>
                                                <option value="6"> 06</option>
                                                <option value="7"> 07</option>
                                                <option value="8"> 08</option>
                                                <option value="9"> 09</option>
                                                <option value="10"> 10</option>
                                                <option value="11"> 11</option>
                                                <option value="12"> 12</option>
                                                <option value="13"> 13</option>
                                                <option value="14"> 14</option>
                                                <option value="15"> 15</option>
                                                <option value="16"> 16</option>
                                                <option value="17"> 17</option>
                                                <option value="18"> 18</option>
                                                <option value="19"> 19</option>
                                                <option value="20"> 20</option>
                                                <option value="21"> 21</option>
                                                <option value="22"> 22</option>
                                                <option value="23"> 23</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="form-group">:
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <select name="minutes" class="form-control minutes">
                                                <option value="0"> 00</option>
                                                <option value="5"> 05</option>
                                                <option value="10"> 10</option>
                                                <option value="15"> 15</option>
                                                <option value="20"> 20</option>
                                                <option value="25"> 25</option>
                                                <option value="30"> 30</option>
                                                <option value="35"> 35</option>
                                                <option value="40"> 40</option>
                                                <option value="45"> 45</option>
                                                <option value="50"> 50</option>
                                                <option value="55"> 55</option>
                                            </select>
                                        </div>
                                    </div>
                                </div> -->
                <!-- End of Reservation Date Picker -->
            </div>
        </div>

        <div class="form-group col-md-12 totales-infos closelist">

        </div>



        <div class="form-group col-md-12 next" form="simple_form">
            <div class="form-error-msg"></div>
            <button type="button" class="btn btn-success btn-submit">Reservation
                &nbsp;&nbsp;</button>
        </div>

    </fieldset>
</form>
<?php /**PATH C:\laragon\www\MyPrivateDriver\resources\views/frontend/components/forms/simple.blade.php ENDPATH**/ ?>