

<?php $__env->startSection('content'); ?>
    <div class="title_page" style="background-image: url(<?php echo e(asset('images/marrakesh-menara-airport_1.jpg')); ?>);">
    
        <h1>AIRPORT TRANSFER</h1>
        <p>We offer a variety of vehicles to choose from, including private cars, shuttle buses, and taxis.
                 With our online booking system and 24/7 support, you can easily arrange your airport transfer.</p>
    </div>
    <div class="container section-2">
        <div class="row">
            <div class="col-md-6 column">
                <div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box-off">
                    <h2>AIRPORT TRANSFER IN MARRAKECH –MOROCO</h2>
                </div>
                
                <p>Our experienced drivers with expert knowledge of Marrakech traffic ensure that you arrive at your destination on time and in comfort. <br><br>
                    Our fleet of well-maintained vehicles caters to all group sizes, and we provide complimentary meet and greet service to welcome you or your guests at the airport. <br><br>
                    We understand that time is of the essence, which is why our chauffeurs will be waiting for you at the airport before your flight lands. <br><br>
                    Whether you are travelling for business or pleasure, our airport pickup service in Marrakech is designed to make your journey as smooth as possible. Simply message or call us to book your instant airport transfer today!</p>

                    <a class="btn-airport_transfer" href="#">Booking Now</a>
            </div>
            <div class="col-md-6">
                <img style="width:100%;border-radius:5%;" src="<?php echo e(asset('images/marrakech-airport-to-marrakech-city-private-transfer-details.jpg')); ?>" alt=""
                srcset="">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\MyPrivateDriver\resources\views/airport_transfer.blade.php ENDPATH**/ ?>