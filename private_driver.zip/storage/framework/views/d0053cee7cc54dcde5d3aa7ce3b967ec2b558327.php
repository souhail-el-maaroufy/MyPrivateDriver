<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Private driver in Marrakech, Casablanca, morocco airport transfers</title>
    <meta name="description" content="Book your Private driver in morocco airport transfer Marrakech &amp; casablanca &amp; your trips everywhere in morocco, its Simpleand fast" />
    <meta name="keywords" content="Private driver, rcd, mercedes class, a luxury car with driver, Marrakech, Morocco, airport, trainstation, guide driver in Marrakech" />
    <meta http-equiv="Expires" content="1">
    <!--share settings-->
    <meta property="og:title" content="Private driver in Marrakech, Casablanca, morocco airport transfers">
    <meta property="og:image" content="https://www.allomycab.ma/images/allomycab-share-en.jpg">
    <meta property="og:description" content="Book your Private driver in morocco airport transfer Marrakech &amp; casablanca &amp; your trips everywhere in morocco, its Simpleand fast">
    <META PROPERTY="OG:URL" content="https://www.allomycab.ma/">
    <meta property="og:type" content="website" />
    <meta property="og:author" content="AlloMyCab" />
    <!--share twitter settings-->
    <meta name="twitter:title" content="Private driver in Marrakech, Casablanca, morocco airport transfers">
    <meta name="twitter:description" content="Book your Private driver in morocco airport transfer Marrakech &amp; casablanca &amp; your trips everywhere in morocco, its Simpleand fast">
    <meta name="twitter:site" content="https://www.allomycab.ma">
    <meta name="twitter:image" content="https://www.allomycab.ma/images/allomycab-share-en.jpg">
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="author" content="the-code.info" />
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" defer />
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" defer>
    <link rel="stylesheet" href="<?php echo e(asset('css/icomoon.css')); ?>" defer>
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>" defer>
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>" defer>
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" defer>
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>" defer>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" defer>
    <link href="https://fonts.googleapis.com/css?family=Maven+Pro:400,700&display=swap" rel="stylesheet" defer>
    <!--<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">-->
    <script src="<?php echo e(asset('js/modernizr-2.6.2.min.js')); ?>" defer></script>
    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o), m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-111295886-1', 'auto');
        ga('send', 'pageview');
    </script>



    <script src="https://www.allomycab.ma/js/jquery.js"></script>

    <script src="https://www.allomycab.ma/js/jquery.easing.1.3.js" defer></script>
    <script src="https://www.allomycab.ma/js/bootstrap.min.js" defer></script>
    <script src="https://www.allomycab.ma/js/jquery.waypoints.min.js" defer></script>
    <script src="https://www.allomycab.ma/js/owl.carousel.min.js" defer></script>
    <script src="https://www.allomycab.ma/js/jquery.countTo.js" defer></script>
    <script src="https://www.allomycab.ma/js/moment.js" defer></script>
    <script src="https://www.allomycab.ma/js/jquery.magnific-popup.min.js" defer></script>
    <script type="text/javascript" src="https://www.allomycab.ma/back/plugins/daterangepicker/daterangepicker.js" defer></script>
    <link rel="stylesheet" type="text/css" href="https://www.allomycab.ma/back/plugins/daterangepicker/daterangepicker.css" />
    <!--<script data-ad-client="ca-pub-7437908478707657" async
    src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>-->
    <link rel="canonical" href="https://www.allomycab.ma/en" />


    <!--<script type="text/javascript" src="https://cdn.rawgit.com/prashantchaudhary/ddslick/master/jquery.ddslick.min.js">
</script>-->
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
<script src="js/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <div id="page">
        <div class="row top-menu">
            <div class="gtco-container">
                <div class="col-md-12 text-right gtco-contact">
                    <ul class="contacts">
                        <li> <a href="tel:+212674091556" title="Call Us"><img src="https://www.allomycab.ma/images/phone.svg" alt="call us" /></a></li>
                        <!--<li><a href="https://www.facebook.com/allomycab/" target = "_blank" title="Our Facebook page" ><img src="https://www.allomycab.ma/images/facebook.svg" alt="Facebook"/></a></li>-->
                        <li> <a href="https://api.whatsapp.com/send?phone=+212674091556&text=Thanks for contacting Allomycab! Tell us how we can help you." title="Send a Message on whattsapp"><img src="https://www.allomycab.ma/images/whatsapp.svg" alt="whatsapp" /></a></li>
                    </ul>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default dropdown-toggle headerlanguages" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="English">
                    English <img src="https://www.allomycab.ma/images/en.svg" alt="contenten-lang-title"><span class="glyphicon glyphicon-chevron-down"></span></button>
                        <ul class="dropdown-menu languages">
                            <li class="active"><a href="https://www.allomycab.ma/en" title="English"><img src="https://www.allomycab.ma/images/en.svg" alt="english" /> English</a></li>
                            <li class=""><a href="https://www.allomycab.ma/fr" title="Français"><img src="https://www.allomycab.ma/images/fr.svg" alt="français" /> Français</a></li>
                            <li class=""><a href="https://www.allomycab.ma/es" title="Español"><img src="https://www.allomycab.ma/images/es.svg" alt="español" /> Español</a></li>
                            <li class=""><a href="https://www.allomycab.ma/ar" title="العربية"><img src="https://www.allomycab.ma/images/ar.svg" alt="العربية" /> العربية</a></li>
                            <li class=""><a href="https://www.allomycab.ma/ch" title="Français"><img src="https://www.allomycab.ma/images/ch.svg" alt="chineese" /> 中文</a></li>
                            <li class=""><a href="https://www.allomycab.ma/ru" title="руссий"><img src="https://www.allomycab.ma/images/ru.svg" alt="русский" /> руссий</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav id="gtco-nav" class="gtco-nav" role="navigation">
            <div class="gtco-container">
                <!-- logo -->
                <div class="row">
                    <div class="col-sm-4 col-xs-12">
                        <div id="gtco-logo"><button onclick="location.href='https://www.allomycab.ma/en'" type="button" title="Accueil &amp; réservation" alt="AlloMyCab: Private driver &amp; airport transfer"><img src="https://www.allomycab.ma/images/allomycab.png" srcset="https://www.allomycab.ma/images/allomycabx2.png" alt="AlloMyCab: Private driver &amp; airport transfer" /> AlloMyCab</button>
                        </div>
                    </div>
                    <!-- menu -->
                    <div class="col-xs-8 text-right menu-1">
                        <ul class="main-menu">
                            <li class="active  "><a href="https://www.allomycab.ma/en" title="Bookings" alt="Bookings">Bookings</a></li>
                            <li class="   has-dropdown">
                                <a href="#0" title="Airport transfer in Morocco" alt="Airport transfer in Morocco">Airport transfer in Morocco</a>
                                <ul class="dropdown">
                                    <li class=""><a href="https://www.allomycab.ma/en/airport-transfer-morocco" title="Airport transfer in Morocco" alt="Airport transfer in Morocco"> Airport transfer in Morocco</a></li>
                                    <li class=""><a href="https://www.allomycab.ma/en/casablanca-airport-transfers" title="Casablanca Mohammed V Airport transfer" alt="Casablanca Mohammed V Airport transfer"> Casablanca Mohammed V Airport transfer </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/marrakech-airport-transfers" title="Marrakech Menara Airport transfer" alt="Marrakech Menara Airport transfer"> Marrakech Menara Airport transfer </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/agadir-airport-transfers" title="Agadir Al Massira Airport Transfer" alt="Agadir Al Massira Airport Transfer"> Agadir Al Massira Airport Transfer </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/rabat-airport-transfers" title="Rabat Salé Airport Transfer" alt="Rabat Salé Airport Transfer"> Rabat Salé Airport Transfer </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/fes-airport-transfers" title="Fès Saïss Airport Transfer" alt="Fès Saïss Airport Transfer"> Fès Saïss Airport Transfer </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/tanger-airport-transfers" title="Tangier Ibn Battouta Airport Transfer" alt="Tangier Ibn Battouta Airport Transfer"> Tangier Ibn Battouta Airport Transfer </a> </li>

                                </ul>
                            </li>

                            <li class="  has-dropdown">
                                <a href="#0" title="Services" alt="Services">Services</a>
                                <ul class="dropdown">
                                    <li class=""><a href="https://www.allomycab.ma/en/airport-transfer-morocco" title="Airport transfer in Morocco" alt="Airport transfer in Morocco"> Airport transfer in Morocco</a></li>
                                    <li class=""><a href="https://www.allomycab.ma/en/we-provide" title="We provide" alt="We provide"> We provide </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/companies" title="Companies" alt="Companies"> Companies </a> </li>
                                    <li class=""><a href="https://www.allomycab.ma/en/wedding-cars-with-driver-morocco" title="Wedding cars with driver in Morocco" alt="Wedding cars with driver in Morocco"> Wedding cars with driver in Morocco </a> </li>

                                </ul>
                            </li>
                            <li class=""><a href="https://www.allomycab.ma/en/our-cars" title="Cars" alt="Cars">Cars</a></li>
                            <li class=""><a href="https://www.allomycab.ma/en/gallery" title="Gallery" alt="Gallery">Gallery</a></li>
                            <li class=""><a href="https://www.allomycab.ma/en/vip-services" title="premium service" alt="premium service">premium service</a></li>

                            <li class=""><a href="https://www.allomycab.ma/en/pricing" title="Prices" alt="Prices">Prices</a></li>
                            <li class=""><a href="https://www.allomycab.ma/en/contact-us" title="Contact" alt="Contact">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <a href="https://api.whatsapp.com/send?phone=+212674091556&text=Thanks for contacting Allomycab! Tell us how we can help you." class="whatsapp-but" title="Send a Message on whattsapp"><img src="https://www.allomycab.ma/images/whatsapp.svg" width="50" height="50" alt="whatsapp" /></a>
        <header id="gtco-header" class="gtco-cover" role="banner" style="background-image:url(https://www.allomycab.ma/images/img_bg_1.jpg);">
            <div class="overlay"></div>
            <div class="gtco-container">
                <div class="row flexit">
                    <div class="col-md-5 col-md-offset-0 text-right">
                        <div class="display-t">
                            <div class="display-tc">
                                <h1 class="animate-box-off" data-animate-effect="fadeInUp">Book your private driver in Morocco : trips and airport transfers </h1>
                                <h3 class="animate-box-off white-text" data-animate-effect="fadeInUp">
                                    All over Morocco : Marrakech, Casablanca, Rabat, Fes, Tangier, Agadir...</h3>
                                <p class='white-text'>
                                    <i style="color: #00ffb1; font-size: 20px;" class='ti-check-box'></i> Save up to 30% on your transfers <br />
                                    <i style="color: #00ffb1; font-size: 20px;" class='ti-check-box'></i> More than 5,234 transfers and cars providing <br />
                                    <i style="color: #00ffb1; font-size: 20px;" class='ti-check-box'></i> 24/7 customer service </p>
                                <p class="white-text animate-box-off mobile-hide ">
                                    Your private driver go along with you on all your trips and your <a href="https://www.allomycab.ma/en/casablanca-airport-transfers" class="link-text-white" alt="Mohammed v airport transfer in Casablanca ( CMN )"> Mohammed v airport transfer in Casablanca ( CMN ) </a>,
                                    <a href="https://www.allomycab.ma/en/marrakech-airport-transfers" class="link-text-white" alt="Marrakech Menara airport transfer ( RAK )"> Marrakech Menara airport transfer ( RAK ) </a> and all over Morocco and its
                                    airports .</p>
                                <a class="white-text animate-box-off header_arrow_p">Check Prices<img src="https://www.allomycab.ma/images/arrow.svg" alt="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer" /></a>
                                <a class="white-text animate-box-off header_arrow_p_mobile">Check Prices<img src="https://www.allomycab.ma/images/arrow-down.svg" alt="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer" /></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7 col-md-offset-0 form-holder">
                        <div class="display-t">
                            <div class="display-tc">
                                <div class="booking-form">

                                    <!-- Nav tabs -->
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li role="simple" class="active"><a href="#simple" aria-controls="home" role="tab" data-toggle="tab"><i class="ti-direction-alt"></i>Route</a></li>
                                        <li role="per_hour"><a href="#heure" aria-controls="profile" role="tab" data-toggle="tab"><i class="ti-time"></i>Per Hour</a></li>
                                    </ul>

                                    <!-- Tab panes -->
                                    <div class="tab-content">

                                        <!-- hourly booking  -->
                                        <div role="tabpanel" class="tab-pane" id="heure">
                                            <form autocomplete="off" id="hourly_form" class="form-horizontal main-form" method="post" action="https://www.allomycab.ma/booking">
                                                <input type="hidden" name="_token" value="p63clH24k5PzPfhezuVCrCH64KgVXaWRC0MsiBXd">
                                                <input type="hidden" name="depart_latlng" value="0">
                                                <input type="hidden" name="destination_latlng" value="0">
                                                <input type="hidden" name="type" value="PER_HOUR">
                                                <input type="hidden" name="date_reservation" class="date_reservation">
                                                <fieldset>
                                                    <div class="time-choices col-md-12">
                                                        <div class="choice later active">Later</div>
                                                        <div class="choice now" data-now="now">Now</div>
                                                    </div>
                                                    <!-- Reservation Date Picker -->
                                                    <div class="form-group col-md-12 date-res infos">

                                                        <label class='date_hours' for="">Date & Hour of departure (Morocco) :&nbsp; <i class="ti-calendar"></i>&nbsp;<i class="ti-timer"></i>
                            <div class="am-pm"></div>
                        </label>

                                                        <div class="infos-but" style="">?</div>

                                                        <label id="infos" class="date_hours" style="">Per-day availability rates apply to service within a single city or within a radius not exceeding 40 km. Otherwise, the price of fuel and motorway tickets will be paid by the customer.</label>

                                                    </div>
                                                    <div class="date-res">
                                                        <div class="col-md-7 form-group">
                                                            <div class="reportrange pull-right  form-control">
                                                                <i class="ti-calendar"></i>&nbsp;
                                                                <span></span> <b class="caret"></b>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-1">
                                                            <div class="form-group"><i class="ti-timer"></i>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <select name="hours" class="form-control hours">
                                    <option value="0"> 00</option>
                                    <option value="1"> 01</option>
                                    <option value="2"> 02</option>
                                    <option value="3"> 03</option>
                                    <option value="4"> 04</option>
                                    <option value="5"> 05</option>
                                    <option value="6"> 06</option>
                                    <option value="7"> 07</option>
                                    <option value="8"> 08</option>
                                    <option value="9"> 09</option>
                                    <option value="10"> 10</option>
                                    <option value="11"> 11</option>
                                    <option value="12"> 12</option>
                                    <option value="13"> 13</option>
                                    <option value="14"> 14</option>
                                    <option value="15"> 15</option>
                                    <option value="16"> 16</option>
                                    <option value="17"> 17</option>
                                    <option value="18"> 18</option>
                                    <option value="19"> 19</option>
                                    <option value="20"> 20</option>
                                    <option value="21"> 21</option>
                                    <option value="22"> 22</option>
                                    <option value="23"> 23</option>
                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-1">
                                                            <div class="form-group">:
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <select name="minutes" class="form-control minutes">
                                    <option value="0"> 00</option>
                                    <option value="5"> 05</option>
                                    <option value="10"> 10</option>
                                    <option value="15"> 15</option>
                                    <option value="20"> 20</option>
                                    <option value="25"> 25</option>
                                    <option value="30"> 30</option>
                                    <option value="35"> 35</option>
                                    <option value="40"> 40</option>
                                    <option value="45"> 45</option>
                                    <option value="50"> 50</option>
                                    <option value="55"> 55</option>
                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- End of Reservation Date Picker -->
                                                    <div class="form-group col-md-12 car-gallery">
                                                        <div id="gall" class="popup-gallery"></div>
                                                        <div id="selected_cars" class="my_selected_cars"></div>
                                                    </div>

                                                    <div class="form-group col-md-12 cars">
                                                        <input type="hidden" class="car_model" name="car_model" value="0" personnes="" bags="" carcode="" carname="" price="0" />
                                                        <button id="choose_car_hourly" type="button" class="hourly_form btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="">
                            <span class="car_chosen_title">You have chosen : </span> <span class="car_chosen" style="color:#334e86;">Choose your car</span>
                            <img class="select_arrows" alt="select arrows" src="https://www.allomycab.ma/images/arrow-select.svg"></button>


                                                        <ul class="dropdown-menu">
                                                            <li class="dropdown-header">Economy</li>
                                                            <li class="car">
                                                                <a id="my_car" title="Van: Hyundai-H1" gallery_type="hourly" carid="17" personnes="5" bags="6" carcode="h1" hour_rate="12" carname="Van: Hyundai-H1">
                                    <img src="https://www.allomycab.ma/images/car_h1.jpg" width="80" alt="Van: Hyundai-H1" />
                                    <span> Van: Hyundai-H1 </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x5
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car" title="Van: Ssangyoung" gallery_type="hourly" carid="16" personnes="6" bags="7" carcode="sy" hour_rate="12" carname="Van: Ssangyoung">
                                    <img src="https://www.allomycab.ma/images/car_sy.jpg" width="80" alt="Van: Ssangyoung" />
                                    <span> Van: Ssangyoung </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x7
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car" title="Van: Renault trafic" gallery_type="hourly" carid="15" personnes="8" bags="10" carcode="rt" hour_rate="12" carname="Van: Renault trafic">
                                    <img src="https://www.allomycab.ma/images/car_rt.jpg" width="80" alt="Van: Renault trafic" />
                                    <span> Van: Renault trafic </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x8
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x10
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="dropdown-header">Comfort</li>
                                                            <li class="car">
                                                                <a id="my_car" title="Mercedes class V" gallery_type="hourly" carid="10" personnes="6" bags="8" carcode="mv" hour_rate="14" carname="Mercedes class V">
                                    <img src="https://www.allomycab.ma/images/car_mv.jpg" width="80" alt="Mercedes class V" />
                                    <span> Mercedes class V </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x8
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car" title="Mercedes Sprinter" gallery_type="hourly" carid="18" personnes="17" bags="20" carcode="ms17" hour_rate="20" carname="Mercedes Sprinter">
                                    <img src="https://www.allomycab.ma/images/car_ms17.jpg" width="80" alt="Mercedes Sprinter" />
                                    <span> Mercedes Sprinter </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x17
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x20
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car" title="Mercedes Classe E" gallery_type="hourly" carid="9" personnes="3" bags="3" carcode="me" hour_rate="20" carname="Mercedes Classe E">
                                    <img src="https://www.allomycab.ma/images/car_me.jpg" width="80" alt="Mercedes Classe E" />
                                    <span> Mercedes Classe E </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x3
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x3
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="dropdown-header">Premium</li>
                                                            <li class="car">
                                                                <a id="my_car" title="Range Rover Sport" gallery_type="hourly" carid="8" personnes="4" bags="6" carcode="rs" hour_rate="25" carname="Range Rover Sport">
                                    <img src="https://www.allomycab.ma/images/car_rs.jpg" width="80" alt="Range Rover Sport" />
                                    <span> Range Rover Sport </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x4
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car" title="Range Rover Vogue" gallery_type="hourly" carid="7" personnes="4" bags="6" carcode="rv" hour_rate="28" carname="Range Rover Vogue">
                                    <img src="https://www.allomycab.ma/images/car_rv.jpg" width="80" alt="Range Rover Vogue" />
                                    <span> Range Rover Vogue </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x4
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car" title="Mercedes Classe S" gallery_type="hourly" carid="6" personnes="3" bags="4" carcode="ms" hour_rate="35" carname="Mercedes Classe S">
                                    <img src="https://www.allomycab.ma/images/car_ms.jpg" width="80" alt="Mercedes Classe S" />
                                    <span> Mercedes Classe S </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x3
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x4
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>
                                    </div>
                                </a>
                                                            </li>
                                                        </ul>

                                                    </div>

                                                    <div class="form-group col-md-12">
                                                        <select name="estimated_cars" class="form-control estimated_cars">
                            <option selected value="0">How many cars do you need</option>
                             <option value="1">1</option>
                                 <option value="2">2</option>
                                 <option value="3">3</option>
                                 <option value="4">4</option>
                                 <option value="5">5</option>
                                 <option value="6">6</option>
                                 <option value="7">7</option>
                                 <option value="8">8</option>
                                 <option value="9">9</option>
                                 <option value="10">10</option>
                                 <option value="11">11</option>
                                 <option value="12">12</option>
                                 <option value="13">13</option>
                                 <option value="14">14</option>
                                 <option value="15">15</option>
                                 <option value="16">16</option>
                                 <option value="17">17</option>
                                 <option value="18">18</option>
                                 <option value="19">19</option>
                                 <option value="20">20</option>
                                 <option value="21">21</option>
                                 <option value="22">22</option>
                                 <option value="23">23</option>
                                 <option value="24">24</option>
                                 <option value="25">25</option>
                                 <option value="26">26</option>
                                 <option value="27">27</option>
                                 <option value="28">28</option>
                                 <option value="29">29</option>
                                 <option value="30">30</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group col-md-12">
                                                        <select name="estimated_days" class="form-control estimated_days">
                            <option selected value="0">How many days</option>
                            <option value="0.5">0.5   ( 5 hours of service / half day )</option>
                             <option value="1">1   ( 10 hours of service / day )</option>
                             <option value="2">2</option>
                                 <option value="3">3</option>
                                 <option value="4">4</option>
                                 <option value="5">5</option>
                                 <option value="6">6</option>
                                 <option value="7">7</option>
                                 <option value="8">8</option>
                                 <option value="9">9</option>
                                 <option value="10">10</option>
                                 <option value="11">11</option>
                                 <option value="12">12</option>
                                 <option value="13">13</option>
                                 <option value="14">14</option>
                                 <option value="15">15</option>
                                 <option value="16">16</option>
                                 <option value="17">17</option>
                                 <option value="18">18</option>
                                 <option value="19">19</option>
                                 <option value="20">20</option>
                                 <option value="21">21</option>
                                 <option value="22">22</option>
                                 <option value="23">23</option>
                                 <option value="24">24</option>
                                 <option value="25">25</option>
                                 <option value="26">26</option>
                                 <option value="27">27</option>
                                 <option value="28">28</option>
                                 <option value="29">29</option>
                                 <option value="30">30</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group col-md-12">
                                                        <select name="estimated_persons" class="form-control estimated_persons">
                            <option value="0">Number of persons</option>
                             <option value="1">1</option>
                                 <option value="2">2</option>
                                 <option value="3">3</option>
                                 <option value="4">4</option>
                                 <option value="5">5</option>
                                 <option value="6">6</option>
                                 <option value="7">7</option>
                                 <option value="8">8</option>
                                 <option value="9">9</option>
                                 <option value="10">10</option>
                                 <option value="11">11</option>
                                 <option value="12">12</option>
                                 <option value="13">13</option>
                                 <option value="14">14</option>
                                 <option value="15">15</option>
                                 <option value="16">16</option>
                                 <option value="17">17</option>
                                 <option value="18">18</option>
                                 <option value="19">19</option>
                                 <option value="20">20</option>
                                 <option value="21">21</option>
                                 <option value="22">22</option>
                                 <option value="23">23</option>
                                 <option value="24">24</option>
                                 <option value="25">25</option>
                                 <option value="26">26</option>
                                 <option value="27">27</option>
                                 <option value="28">28</option>
                                 <option value="29">29</option>
                                 <option value="30">30</option>
                                                        </select>
                                                    </div>

                                                    <input type="hidden" class="data" name="data" value="0" />
                                                    <div class="form-group col-md-12 next" form="hourly_form">
                                                        <div id="errors_form_hourly" class="form-error-msg"></div>
                                                        <button type="button" class="btn btn-success btn-submit">Reservation&nbsp;&nbsp;</button>
                                                    </div>
                                                </fieldset>
                                            </form>
                                        </div>
                                        <!-- tab simple path -->
                                        <div role="tabpanel" class="tab-pane active" id="simple">
                                            <form autocomplete="off" id="simple_form" class="form-horizontal main-form" method="post" action="https://www.allomycab.ma/booking">
                                                <input type="hidden" name="_token" value="p63clH24k5PzPfhezuVCrCH64KgVXaWRC0MsiBXd">
                                                <input type="hidden" name="depart_latlng" value="0">
                                                <input type="hidden" name="destination_latlng" value="0">
                                                <input type="hidden" name="type" value="SIMPLE">
                                                <input type="hidden" class="is_airport" name="is_airport" value="0">
                                                <input type="hidden" name="date_reservation" class="date_reservation" value="">
                                                <fieldset>
                                                    <div class="time-choices col-md-12">
                                                        <div class="choice later active">Later</div>
                                                        <div class="choice now" data-now="now">Now</div>
                                                    </div>
                                                    <!-- Reservation Date Picker -->
                                                    <div class="form-group col-md-12 date-res">
                                                        <label class='date_hours' for="">Date & Hour of departure (Morocco) :&nbsp; <i class="ti-calendar"></i>&nbsp;<i class="ti-timer"></i>
                            <div class="am-pm"></div>
                        </label>

                                                    </div>
                                                    <div class="date-res">
                                                        <div class="col-md-7 form-group">
                                                            <div class="reportrange pull-right  form-control">
                                                                <i class="ti-calendar"></i>&nbsp;
                                                                <span></span> <b class="caret"></b>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-1">
                                                            <div class="form-group"><i class="ti-timer"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">

                                                                <select name="hours" class="form-control hours">
                                    <option value="0"> 00</option>
                                    <option value="1"> 01</option>
                                    <option value="2"> 02</option>
                                    <option value="3"> 03</option>
                                    <option value="4"> 04</option>
                                    <option value="5"> 05</option>
                                    <option value="6"> 06</option>
                                    <option value="7"> 07</option>
                                    <option value="8"> 08</option>
                                    <option value="9"> 09</option>
                                    <option value="10"> 10</option>
                                    <option value="11"> 11</option>
                                    <option value="12"> 12</option>
                                    <option value="13"> 13</option>
                                    <option value="14"> 14</option>
                                    <option value="15"> 15</option>
                                    <option value="16"> 16</option>
                                    <option value="17"> 17</option>
                                    <option value="18"> 18</option>
                                    <option value="19"> 19</option>
                                    <option value="20"> 20</option>
                                    <option value="21"> 21</option>
                                    <option value="22"> 22</option>
                                    <option value="23"> 23</option>

                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-1">
                                                            <div class="form-group">:
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <select name="minutes" class="form-control minutes">
                                    <option value="0"> 00</option>
                                    <option value="5"> 05</option>
                                    <option value="10"> 10</option>
                                    <option value="15"> 15</option>
                                    <option value="20"> 20</option>
                                    <option value="25"> 25</option>
                                    <option value="30"> 30</option>
                                    <option value="35"> 35</option>
                                    <option value="40"> 40</option>
                                    <option value="45"> 45</option>
                                    <option value="50"> 50</option>
                                    <option value="55"> 55</option>
                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- End of Reservation Date Picker -->

                                                    <div class="form-group col-md-12 cars" style="display:none;">
                                                        <input type="hidden" class="car_model" name="car_model" value="0" personnes="" bags="" carcode="" carname="" price="0" />
                                                        <button id="choose_car_simple" type="button" class="simple_form btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="">
                            <span class="car_chosen_title">You have chosen : </span> <span class="car_chosen" style="color:#334e86;">Choose your car</span>
                            <img class="select_arrows" alt="select arrows" src="https://www.allomycab.ma/images/arrow-select.svg"></button>

                                                        <ul class="dropdown-menu">
                                                            <li class="dropdown-header">Economy</li>
                                                            <li class="car">
                                                                <a id="my_car_11" title="Van: Hyundai-H1" gallery_type="simple" carid="11" personnes="5" price_airport="25" bags="6" carcode="h1" price_min="25" order="2" price_day="140" price_half="80" price_km="1.1" hour_rate="12" available="1" carname="Van: Hyundai-H1">
                                    <img src="https://www.allomycab.ma/images/car_h1.jpg" width="80" alt="Van: Hyundai-H1" />
                                    <span> Van: Hyundai-H1 </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x5
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x6
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car_13" title="Van: Ssangyoung" gallery_type="simple" carid="13" personnes="6" price_airport="30" bags="7" carcode="sy" price_min="19" order="3" price_day="140" price_half="80" price_km="1.1" hour_rate="12" available="1" carname="Van: Ssangyoung">
                                    <img src="https://www.allomycab.ma/images/car_sy.jpg" width="80" alt="Van: Ssangyoung" />
                                    <span> Van: Ssangyoung </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x7
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car_14" title="Van: Renault trafic" gallery_type="simple" carid="14" personnes="8" price_airport="35" bags="10" carcode="rt" price_min="24" order="4" price_day="120" price_half="80" price_km="1.15" hour_rate="12" available="1" carname="Van: Renault trafic">
                                    <img src="https://www.allomycab.ma/images/car_rt.jpg" width="80" alt="Van: Renault trafic" />
                                    <span> Van: Renault trafic </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x8
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x10
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="dropdown-header">Comfort</li>
                                                            <li class="car">
                                                                <a id="my_car_5" title="Mercedes V class" gallery_type="simple" carid="5" personnes="6" price_airport="36" bags="8" carcode="mv" price_min="36" order="5" price_day="139" price_half="90" price_km="1.15" hour_rate="14" available="1" carname="Mercedes V class">
                                    <img src="https://www.allomycab.ma/images/car_mv.jpg" width="80" alt="Mercedes V class" />
                                    <span> Mercedes V class </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x6
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x8
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car_12" title="Mercedes Sprinter" gallery_type="simple" carid="12" personnes="17" price_airport="60" bags="20" carcode="ms17" price_min="60" order="9" price_day="199" price_half="120" price_km="1.8" hour_rate="20" available="1" carname="Mercedes Sprinter">
                                    <img src="https://www.allomycab.ma/images/car_ms17.jpg" width="80" alt="Mercedes Sprinter" />
                                    <span> Mercedes Sprinter </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x17
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x20
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car_4" title="Mercedes E class" gallery_type="simple" carid="4" personnes="3" price_airport="50" bags="3" carcode="me" price_min="50" order="10" price_day="199" price_half="150" price_km="1.8" hour_rate="20" available="1" carname="Mercedes E class">
                                    <img src="https://www.allomycab.ma/images/car_me.jpg" width="80" alt="Mercedes E class" />
                                    <span> Mercedes E class </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x3
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x3
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="dropdown-header">Premium</li>
                                                            <li class="car">
                                                                <a id="my_car_3" title="Range Rover Sport" gallery_type="simple" carid="3" personnes="4" price_airport="80" bags="6" carcode="rs" price_min="80" order="20" price_day="250" price_half="180" price_km="2" hour_rate="25" available="1" carname="Range Rover Sport">
                                    <img src="https://www.allomycab.ma/images/car_rs.jpg" width="80" alt="Range Rover Sport" />
                                    <span> Range Rover Sport </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x4
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x6
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car_2" title="Range Rover Vogue" gallery_type="simple" carid="2" personnes="4" price_airport="110" bags="6" carcode="rv" price_min="110" order="30" price_day="390" price_half="270" price_km="2.3" hour_rate="30" available="1" carname="Range Rover Vogue">
                                    <img src="https://www.allomycab.ma/images/car_rv.jpg" width="80" alt="Range Rover Vogue" />
                                    <span> Range Rover Vogue </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x4
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x6
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                            <li class="car">
                                                                <a id="my_car_1" title="Mercedes S Class" gallery_type="simple" carid="1" personnes="3" price_airport="135" bags="4" carcode="ms" price_min="135" order="40" price_day="450" price_half="300" price_km="2.7" hour_rate="35" available="1" carname="Mercedes S Class">
                                    <img src="https://www.allomycab.ma/images/car_ms.jpg" width="80" alt="Mercedes S Class" />
                                    <span> Mercedes S Class </span>
                                    <div style="float:right; padding: 1.5% 1%;">
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/men.svg"><span>x3
                                            </span></div>
                                        <div class="car-details"><img src="https://www.allomycab.ma/images/laguage.svg"><span>x4
                                            </span></div>
                                        <!-- <div class="car-details"><img src="https://www.allomycab.ma/images/wifi.svg"></div>-->
                                    </div>
                                </a>
                                                            </li>
                                                        </ul>

                                                    </div>

                                                    <div class="form-group col-md-12">
                                                        <input required autocomplete="off" style="width:88%; float:left;" type="text" class="form-control departSelector depart" placeholder="Departure : adress, hotel, airport..." name="depart" id="depart">
                                                        <a href="" class="geolocalize-me" title="My location" id="geo_depart"><img src="https://www.allomycab.ma/images/localize.svg" alt="geolocalisation" /></a>
                                                    </div>
                                                    <div class="form-group col-md-12">
                                                        <input style="width:88%; float:left;" required autocomplete="off" type="text" class="form-control arriveeSelector destination" placeholder="Destination : adress, hotel, airport..." name="destination" id="destination">
                                                        <a href="" class="geolocalize-me" title="My location" id="geo_destination"><img src="https://www.allomycab.ma/images/localize.svg" alt="geolocalisation" /></a>
                                                    </div>

                                                    <div id="cars_prices" class="form-group col-md-12">
                                                        <input type="hidden" class="car_model" name="car_model" value="0" personnes="" price="0" bags="" carcode="" carname="" />
                                                        <ul>

                                                        </ul>
                                                    </div>

                                                    <div class="form-group col-md-12 car-gallery">
                                                        <div id="gall" class="popup-gallery"></div>
                                                        <div id="selected_cars" class="my_selected_cars">
                                                        </div>
                                                    </div>

                                                    <input type="hidden" class="data" name="data" value="0" />
                                                    <!--
                             <div class="form-group col-md-12 two-ways">
                                <div class="form-error-msg"></div>
                                <button type="button" class="btn btn-success btn-submit dif">Two ways                                    &nbsp;&nbsp;</button>
                            </div>
                                    -->

                                                    <div class="twoways-container closelist">
                                                        <div class="form-group col-md-6 switcher go-switch">
                                                            <label class="form-switch">
                                <input type="checkbox" id="twoways" name="twoways" class="twoways">
                                <i></i>
                                Two ways ? <br />
                            </label>
                                                        </div>

                                                        <div class="form-group col-md-6 switcher back-switch">
                                                            <label class="form-switch">
                                <input type="checkbox" id="back-switch" name="back-switch" class="twoways">
                                <i></i>
                                Date retour différente ?
                            </label>
                                                        </div>

                                                        <div class="form-group col-md-12 waiting-hours closelist">
                                                            <select id="waite-time" name="wait-time" class="form-control" class="waite-time">
                                <option selected value="0"> Waiting hours ( Optional )</option>
                                <option value="1"> 1 Hour</option>
                                <option value="2"> 2 Hours</option>
                                <option value="3"> 3 Hours</option>
                                <option value="4"> 4 Hours</option>
                                <option value="5"> 5 Hours</option>
                                <option value="6"> 6 Hours</option>
                                <option value="7"> 7 Hours</option>
                                <option value="8"> 8 Hours</option>
                            </select>
                                                        </div>



                                                        <div class="back_date closelist">
                                                            <!-- Reservation Date Picker -->
                                                            <!-- <div class="form-group col-md-12 date-res">
                            <label class='date_hours' for="">Date & Hour of departure (Morocco) :&nbsp; <i
                                    class="ti-calendar"></i>&nbsp;<i class="ti-timer"></i>  <div class="am-pm"></div></label>
                                   
                        </div> -->
                                                            <!-- <input type="hidden" name="back_date_reservation" class="back_date_reservation" value="">
                        <div class="date-res">
                           
                            <div class="col-md-7 form-group">
                                <div class="reportrange pull-right  form-control">
                                    <i class="ti-calendar"></i>&nbsp;
                                    <span></span> <b class="caret"></b>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <div class="form-group"><i class="ti-timer"></i>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                
                                    <select name="hours" class="form-control hours">
                                        <option value="0"> 00</option>
                                        <option value="1"> 01</option>
                                        <option value="2"> 02</option>
                                        <option value="3"> 03</option>
                                        <option value="4"> 04</option>
                                        <option value="5"> 05</option>
                                        <option value="6"> 06</option>
                                        <option value="7"> 07</option>
                                        <option value="8"> 08</option>
                                        <option value="9"> 09</option>
                                        <option value="10"> 10</option>
                                        <option value="11"> 11</option>
                                        <option value="12"> 12</option>
                                        <option value="13"> 13</option>
                                        <option value="14"> 14</option>
                                        <option value="15"> 15</option>
                                        <option value="16"> 16</option>
                                        <option value="17"> 17</option>
                                        <option value="18"> 18</option>
                                        <option value="19"> 19</option>
                                        <option value="20"> 20</option>
                                        <option value="21"> 21</option>
                                        <option value="22"> 22</option>
                                        <option value="23"> 23</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <div class="form-group">:
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <select name="minutes" class="form-control minutes">
                                        <option value="0"> 00</option>
                                        <option value="5"> 05</option>
                                        <option value="10"> 10</option>
                                        <option value="15"> 15</option>
                                        <option value="20"> 20</option>
                                        <option value="25"> 25</option>
                                        <option value="30"> 30</option>
                                        <option value="35"> 35</option>
                                        <option value="40"> 40</option>
                                        <option value="45"> 45</option>
                                        <option value="50"> 50</option>
                                        <option value="55"> 55</option>
                                    </select>
                                </div>
                            </div>
                        </div> -->
                                                            <!-- End of Reservation Date Picker -->
                                                        </div>
                                                    </div>

                                                    <div class="form-group col-md-12 totales-infos closelist">

                                                    </div>



                                                    <div class="form-group col-md-12 next" form="simple_form">
                                                        <div class="form-error-msg"></div>
                                                        <button type="button" class="btn btn-success btn-submit">Reservation                            &nbsp;&nbsp;</button>
                                                    </div>

                                                </fieldset>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </header>


        <div id="gtco" class="gtco-section reviews">
            <div class="gtco-container gtco-heading">
                <div class="col-md-6">
                    <h2 style="color:#fff;">Allomycab <br/> easy and fast transport</h2>
                </div>
                <div class="col-md-6">
                    <ul class="avis">
                        <li><img class="avis-img" src="https://www.allomycab.ma/images/avis_en.svg" alt="Customers reviews"></li>
                        <li><img class="star" src="https://www.allomycab.ma/images/star.svg" alt="Customers reviews"></li>
                        <li><img class="star" src="https://www.allomycab.ma/images/star.svg" alt="Customers reviews"></li>
                        <li><img class="star" src="https://www.allomycab.ma/images/star.svg" alt="Customers reviews"></li>
                        <li><img class="star" src="https://www.allomycab.ma/images/star.svg" alt="Customers reviews"></li>
                        <li><img class="star" src="https://www.allomycab.ma/images/star.svg" alt="Customers reviews"></li>
                        <li>(4.9/5) 550 Customers reviews</li>
                    </ul>
                </div>
            </div>
        </div>


        <div id="gtco" class="gtco-section need">
            <div class="gtco-container">
                <div class="col-md-6 carousel-home">
                    <div class="row animate-box-off">
                        <div class="col-md-12">
                            <div class="owl-carousel owl-carousel-fullwidth">
                                <div class="item"> <img src="https://www.allomycab.ma/images/mercedes-classe-v-avec-chauffeur.jpg" alt="Mercedes-Benz V-Class"> </div>
                                <div class="item"> <img src="https://www.allomycab.ma/images/class-e-transfert-aeroport.jpg" alt="Mercedes-Benz E-Class"> </div>
                                <div class="item"> <img src="https://www.allomycab.ma/images/mercedes-classe-e-interieur-arriere.jpg" alt="Mercedes-Benz E-Class"> </div>
                                <div class="item"> <img src="https://www.allomycab.ma/images/airport-mohammed-v-transfer.jpg" alt="Mercedes-Benz E-Class"> </div>
                                <div class="item"> <img src="https://www.allomycab.ma/images/rang_vogue.jpg" alt="Range Rover Vogue"> </div>
                                <div class="item">
                                    <video width="100%" controls="controls" src="https://www.allomycab.ma/videos/marrakech-video.mp4" type="video/mp4"></video>
                                </div>
                                <div class="item"> <img src="https://www.allomycab.ma/images/classe-v-interieur.jpg" alt="Mercedes-Benz V-Class"> </div>
                                <div class="item"> <img src="https://www.allomycab.ma/images/marrakech-airport-transfer.jpg" alt="Mercedes-Benz V-Class"> </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12 col-md-offset-1  gtco-heading animate-box-off">
                            <h2>private driver in Morocco : Marrakech, Casablanca, Rabat, Agadir and all over the country.</h2>
                            <p>We are a platforme of professional Chauffeur service with cars and sedans. We are specialized in the transportation of people in Morocco Marrakech , Casablanca, Rabat ... an alternative to Moroccan taxis. We work with professionals
                                tourists and individuals to defend the Made in Morocco product of the Private driver profession. We guarantee the satisfaction of our customers till 100%. We go along with you during all your trips in Marrakech and its
                                suburbs. We are also available for your business trips parties, weddings, meetings and conferences , your airport transfer & pick up in casablanca, marrakech and the other cities.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div id="gtco" class="gtco-section features no-padd">
            <div class="gtco-container">
                <div class="gtco-flex">
                    <div class="col-md-4" data-animate-effect="fadeInUp">
                        <div class="feature-inner">
                            <img class="feature-img" src="https://www.allomycab.ma/images/booking.jpg" alt="trans('content.online-reservation-title')">
                            <h3>Online booking</h3>
                            <p>No more surcharged numbers and long waiting to find a taxi in Marrakech. With Allomycab booking your private driver for all your trips in Morocco, your airport transfer in casablanca, marrakech and all the other cities , or
                                on our phone line +212 674 091 556. No booking fees.</p>
                            <p><a href="#" class="btn btn-white btn-outline js-gotop" title="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer" alt="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer">CHECK PRICES</a></p>
                        </div>
                    </div>
                    <div class="col-md-4" data-animate-effect="fadeInUp">
                        <div class="feature-inner">
                            <img class="feature-img" src="https://www.allomycab.ma/images/confirmation.jpg" alt="trans('content.reservation-confirmation-title')">
                            <h3>Booking confirmation</h3>
                            <p>After making your reservation, you will receive a confirmation message by email or SMS indicating your address, the date and time of your pick-up, your destination, and the name of your private driver.</p>
                            <p><a href="#" class="btn btn-white btn-outline js-gotop" title="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer" alt="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer">CHECK PRICES</a></p>
                        </div>
                    </div>
                    <div class="col-md-4" data-animate-effect="fadeInUp">
                        <div class="feature-inner">
                            <img class="feature-img" src="https://www.allomycab.ma/images/ponctualite.jpg" alt="trans('content.service-quality-title')">
                            <h3>Punctuality & quality of service </h3>
                            <p>Our range of vehicles: Latest luxurious cars and vans mixed from French and German best vehicles, equipped with the latest technologies. We offer quality service with major discounts and touristic cars with a personal driver.
                                Our services on board:air condition Bottle of water, charger, sweets, tablet & wifi... </p>
                            <p><a title="SEE MORE" alt="SEE MORE" href="https://www.allomycab.ma/en/vip-services" class="btn btn-white btn-outline">SEE MORE</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="" class="gtco-section">
            <div class="gtco-container">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box-off">
                            <h2>Satisfied clients</h2>
                        </div>
                    </div>
                    <div class="gal popup-gallery">
                        <a href="https://www.allomycab.ma/images/gallery/img_1.jpg" title="Provision of van in Marrakech" alt="Provision of van in Marrakech"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_1.jpg" title="Provision of van in Marrakech" alt="Provision of van in Marrakech" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_2.jpg" title="group transportation in morocco" alt="group transportation in morocco"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_2.jpg" title="group transportation in morocco" alt="group transportation in morocco" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_3.jpg" title="Prado 4x4 car with driver" alt="Prado 4x4 car with driver"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_3.jpg" title="Prado 4x4 car with driver" alt="Prado 4x4 car with driver" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_4.jpg" title="range rover vogue service vip" alt="range rover vogue service vip"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_4.jpg" title="range rover vogue service vip" alt="range rover vogue service vip" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_5.jpg" title="range rover vogue with driver in casablanca" alt="range rover vogue with driver in casablanca"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_5.jpg" title="range rover vogue with driver in casablanca" alt="range rover vogue with driver in casablanca" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_6.jpg" title="airport transfer with range rover vogue luxury car" alt="airport transfer with range rover vogue luxury car"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_6.jpg" title="airport transfer with range rover vogue luxury car" alt="airport transfer with range rover vogue luxury car" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_7.jpg" title="casablanca airport luxury car" alt="casablanca airport luxury car"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_7.jpg" title="casablanca airport luxury car" alt="casablanca airport luxury car" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_8.jpg" title="agadir airport transfer" alt="agadir airport transfer"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_8.jpg" title="agadir airport transfer" alt="agadir airport transfer" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_9.jpg" title="provision of range rover" alt="provision of range rover"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_9.jpg" title="provision of range rover" alt="provision of range rover" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_10.jpg" title="provision of several range rover vogue" alt="provision of several range rover vogue"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_10.jpg" title="provision of several range rover vogue" alt="provision of several range rover vogue" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_11.jpg" title="provision of a VIP car for stars" alt="provision of a VIP car for stars"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_11.jpg" title="provision of a VIP car for stars" alt="provision of a VIP car for stars" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_12.jpg" title="provision of a sports athlete&#039;s vip car" alt="provision of a sports athlete&#039;s vip car"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_12.jpg" title="provision of a sports athlete&#039;s vip car" alt="provision of a sports athlete&#039;s vip car" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_13.jpg" title="provision of VIP car of movie stars" alt="provision of VIP car of movie stars"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_13.jpg" title="provision of VIP car of movie stars" alt="provision of VIP car of movie stars" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_14.jpg" title="provision of car for vip pop singer" alt="provision of car for vip pop singer"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_14.jpg" title="provision of car for vip pop singer" alt="provision of car for vip pop singer" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_15.jpg" title="car with driver for vip" alt="car with driver for vip"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_15.jpg" title="car with driver for vip" alt="car with driver for vip" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_16.jpg" title="professional private driver" alt="professional private driver"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_16.jpg" title="professional private driver" alt="professional private driver" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_17.jpg" title="operation made available several Mercedes sedans" alt="operation made available several Mercedes sedans"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_17.jpg" title="operation made available several Mercedes sedans" alt="operation made available several Mercedes sedans" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_18.jpg" title="provision of Mercedes E class sedan" alt="provision of Mercedes E class sedan"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_18.jpg" title="provision of Mercedes E class sedan" alt="provision of Mercedes E class sedan" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_19.jpg" title="provision of Mercedes E class sedan" alt="provision of Mercedes E class sedan"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_19.jpg" title="provision of Mercedes E class sedan" alt="provision of Mercedes E class sedan" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_20.jpg" title="provision of Mercedes E class sedan" alt="provision of Mercedes E class sedan"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_20.jpg" title="provision of Mercedes E class sedan" alt="provision of Mercedes E class sedan" /></a>
                        <a href="https://www.allomycab.ma/images/gallery/img_21.jpg" title="provision of 4x4 morocco" alt="provision of 4x4 morocco"><img style="width:100%" src="https://www.allomycab.ma/images/gallery/img_21.jpg" title="provision of 4x4 morocco" alt="provision of 4x4 morocco" /></a>
                    </div>
                </div>
                <p class="text-center"><a title="SEE MORE" alt="SEE MORE" href="https://www.allomycab.ma/en/gallery" class="btn btn-white btn-outline">SEE MORE</a></p>
            </div>
        </div>


        <div id="gtco-portfolio" class="gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box-off">
                        <h2>Our luxurious cars and vans</h2>
                    </div>
                </div>
                <div class="row row-pb-md">
                    <div class="col-md-12">
                        <ul id="gtco-portfolio-list">

                            <li class="one-half animate-box-off" data-animate-effect="fadeIn" style="background-image: url(https://www.allomycab.ma/images/img_6.jpg); ">
                                <a href="https://www.allomycab.ma/en/our-cars" class="color-4" title="Mercedes-Benz V-Class">
                                    <div class="case-studies-summary">
                                        <h3 class="white-text">Mercedes-Benz V-Class</h3>
                                        <p><i class="ti-arrow-circle-left"></i> Exterior appearance</p>
                                    </div>
                                </a>
                            </li>
                            <li class="one-half animate-box-off" data-animate-effect="fadeIn" style="background-image: url(https://www.allomycab.ma/images/img_4.jpg);">
                                <a href="https://www.allomycab.ma/en/our-cars" class="color-3" title="Mercedes-Benz SPRINTER">
                                    <div class="case-studies-summary">
                                        <h3 class="white-text">Mercedes-Benz SPRINTER</h3>
                                        <p><i class="ti-arrow-circle-left"></i> Exterior appearance</p>
                                    </div>
                                </a>
                            </li>
                            <li class="one-half animate-box-off" data-animate-effect="fadeIn" style="background-image: url(https://www.allomycab.ma/images/rang_sport.jpg);">
                                <a href="https://www.allomycab.ma/en/our-cars" class="color-3" title="Range Rover Sport">
                                    <div class="case-studies-summary">
                                        <h3 class="white-text">Range Rover Sport</h3>
                                        <p><i class="ti-arrow-circle-left"></i> Exterior appearance</p>
                                    </div>
                                </a>
                            </li>
                            <li class="one-half animate-box-off" data-animate-effect="fadeIn" style="background-image: url(https://www.allomycab.ma/images/class-e-transfert-aeroport.jpg); ">
                                <a href="https://www.allomycab.ma/en/our-cars" class="color-4" title="Mercedes-Benz E-Class">
                                    <div class="case-studies-summary">
                                        <h3 class="white-text">Mercedes-Benz E-Class</h3>
                                        <p><i class="ti-arrow-circle-left"></i> Exterior appearance</p>
                                    </div>
                                </a>
                            </li>
                            <li class="one-half animate-box-off" data-animate-effect="fadeIn" style="background-image: url(https://www.allomycab.ma/images/img_class_s.jpg);">
                                <a href="https://www.allomycab.ma/en/our-cars" class="color-3" title="Mercedes-Benz S-Class">
                                    <div class="case-studies-summary">
                                        <h3 class="white-text">Mercedes-Benz S-Class</h3>
                                        <p><i class="ti-arrow-circle-left"></i> Exterior appearance</p>
                                    </div>
                                </a>
                            </li>
                            <li class="one-half animate-box-off" data-animate-effect="fadeIn" style="background-image: url(https://www.allomycab.ma/images/rang_vogue.jpg); ">
                                <a href="https://www.allomycab.ma/en/our-cars" class="color-4" title="Range Rover Vogue">
                                    <div class="case-studies-summary">
                                        <h3 class="white-text">Range Rover Vogue</h3>
                                        <p><i class="ti-arrow-circle-left"></i> Exterior appearance</p>
                                    </div>
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div id="gtco-counter" class="gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box-off">
                        <h2>Allomycab go along with you.</h2>
                        <p>During all your trips and transfers. We offer a personal warm welcome and insurance in case of delay of your plane or train: our driver will wait 1 hour for your arrival for free ... Enjoy the ride with Allomycab</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6 animate-box-off" data-animate-effect="fadeInLeft">
                        <div class="feature-center"><span class="icon"> <i class="ti-car"></i> </span>
                            <span class="counter js-counter" data-from="0" data-to="78070" data-speed="2000" data-refresh-interval="50">78070</span> <span class="counter-label">Kilometeres crossed</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 animate-box-off" data-animate-effect="fadeInLeft">
                        <div class="feature-center"><span class="icon"> <i class="ti-face-smile"></i> </span>
                            <span class="counter js-counter" data-from="0" data-to="4350" data-speed="2000" data-refresh-interval="50">4350</span> <span class="counter-label">Satisfied clients</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 animate-box-off" data-animate-effect="fadeInLeft">
                        <div class="feature-center"><span class="icon"> <i class="ti-briefcase"></i> </span>
                            <span class="counter js-counter" data-from="0" data-to="5234" data-speed="2000" data-refresh-interval="50">5234</span> <span class="counter-label">Paths crossed</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 animate-box-off" data-animate-effect="fadeInLeft">
                        <div class="feature-center"><span class="icon"> <i class="ti-timer"></i> </span>
                            <span class="counter js-counter" data-from="0" data-to="212023" data-speed="2000" data-refresh-interval="50">212023</span> <span class="counter-label">Working hours</span>
                        </div>
                    </div>
                </div>
                <div id="gtco-subscribe" class="interpage animate-box-off js-top"><a href="https://www.allomycab.ma/en/casablanca-airport-transfers" title="Casablanca Mohammed V Airport transfer" alt="Casablanca Mohammed V Airport transfer" class="btn btn-default btn-block">CHECK PRICES</a></div>
            </div>
        </div>

        <div id="gtco-portfolio">
            <div class="gtco-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box-off">
                        <h2>PAYMENT METHODS</h2>
                        <p>Our vehicles are equipped with payment terminals, you can also pay by Credit Card safely, or you can pay in cash or simply by paying directly on our website</p>
                        <div id="gtco-subscribe" class="interpage animate-box-off js-top"><a href="#" class="btn btn-default btn-block js-gotop" title="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer" alt="EVALUATE THE PRICE: Private driver in Marrakech &amp; Casablanca airport transfer">CHECK PRICES</a></div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <footer id="gtco-footer" class=" " role="contentinfo">
        <div class="gtco-container">
            <div class="row row-p   b-md">
                <div class="col-md-4">
                    <div class="gtco-widget">
                        <h3>WHO WE ARE?</h3>
                        <p>We are a platforme of professional Chauffeur, drivers service with cars and sedans. A car rental of luxurious cars and sedans. We are specialized in the transportation of people in Marrakech and it’s region and all over morocco,
                            an alternative to the Moroccan taxis. We work with professionals, tourists and individuals to defend the Made in Morocco product of the hybrid driver & private dirver profession.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="gtco-widget">
                        <h3>Useful Links</h3>
                        <ul class="gtco-footer-links">
                            <li><a href="https://www.allomycab.ma/en" title="Bookings" alt="Bookings">- Bookings</a></li>
                            <li><a href="https://www.allomycab.ma/en/vip-services" title="premium service" alt="premium service">-
                                premium service</a></li>
                            <li><a href="https://www.allomycab.ma/en/airport-transfer-morocco" title="Airport transfer in Morocco" alt="Airport transfer in Morocco">-
                                Airport transfer in Morocco</a></li>
                            <li><a href="https://www.allomycab.ma/en/casablanca-airport-transfers" title="Casablanca Mohammed V Airport transfer" alt="Casablanca Mohammed V Airport transfer"> -
                                Casablanca Mohammed V Airport transfer</a></li>
                            <li><a href="https://www.allomycab.ma/en/marrakech-airport-transfers" title="Marrakech Menara Airport transfer" alt="Marrakech Menara Airport transfer">- Marrakech Menara Airport transfer</a>
                            </li>
                            <li><a href="https://www.allomycab.ma/en/agadir-airport-transfers" title="Agadir Al Massira Airport Transfer" alt="Agadir Al Massira Airport Transfer">- Agadir Al Massira Airport Transfer</a>
                            </li>
                            <li><a href="https://www.allomycab.ma/en/rabat-airport-transfers" title="Rabat Salé Airport Transfer" alt="Rabat Salé Airport Transfer">- Rabat Salé Airport Transfer</a>
                            </li>
                            <li><a href="https://www.allomycab.ma/en/fes-airport-transfers" title="Fès Saïss Airport Transfer" alt="Fès Saïss Airport Transfer">-
                                Fès Saïss Airport Transfer</a>
                            </li>
                            <li><a href="https://www.allomycab.ma/en/tanger-airport-transfers" title="Tangier Ibn Battouta Airport Transfer" alt="Tangier Ibn Battouta Airport Transfer">- Tangier Ibn Battouta Airport Transfer</a>
                            </li>
                            <li><a href="https://www.allomycab.ma/en/wedding-cars-with-driver-morocco" title="Wedding cars with driver in Morocco" alt="Wedding cars with driver in Morocco">-
                                Wedding cars with driver in Morocco</a>
                            </li>
                            <li><a href="https://www.allomycab.ma/en/pricing" title="Prices" alt="Prices">-
                                Prices</a></li>
                            <li><a href="https://www.allomycab.ma/en/we-provide" title="We provide" alt="We provide">-
                                We provide</a></li>
                            <li><a href="https://www.allomycab.ma/en/contact-us" title="Contact" alt="Contact">-
                                Contact</a></li>
                            <li><a href="https://www.allomycab.ma/en/terms-conditions" title="Terms and conditions" alt="Terms and conditions">-
                                Terms and conditions</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="gtco-widget">
                        <h3>Contact Us</h3>
                        <ul class="gtco-quick-contact">
                            <li><a href="https://www.facebook.com/allomycab/" rel="noreferrer" target="_blank"><img src="https://www.allomycab.ma/images/facebook.svg" width="40" alt="Facebook" /></a></li>
                            <li><i class="icon-phone"></i> +212 674 091 556</li>
                            <li><a href="mailto:allomycab@gmail.com" title="contcat"><i class="icon-mail2"></i> allomycab@gmail.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row copyright">
                <div class="col-md-12">
                    <p class="pull-left">
                        <small class="block">&copy; 2018 Allomycab - PERSONNAL DRIVER IN Marrakech..</small>
                        <small class="block">Sponsored & produced by : <a href="https://the-code.info/" rel="noreferrer" target="_blank" title="Sponsored &amp; produced by :">the-code.info</a></small>
                    </p>
                    <p class="pull-right">
                        <ul class="gtco-social-icons pull-right">
                        </ul>
                    </p>
                </div>
            </div>
        </div>
    </footer>
    </div>
    <script>
        var cost_per_km = "3";
        var min_cost = "30";
        var FORM_ERROR = "Please complete all required fields";
        var INCORRECT_ADD = "Adresses invalides, veuillez vérifier! ";
        var PROCESSING_MSG = "Demand in progress, please wait... ";
        var geocode_disabled = "Sorry We cannot get your position : please enable the geolocalisation on your device or simply try to write your adresse or the nearest place to you ";
        var you_have_chosen = "You have chosen : ";
        var assest = "https://www.allomycab.ma/";
        var vehiculetype0 = "Premium";
        var vehiculetype3 = "Comfort";
        var vehiculetype6 = "Economy";
        var text_duration = "Duration : ";
        var text_distance = "Distance : ";
        var vehicule_choice = "Please choose your vehicle ";
        var ALLER = "Go price ";
        var RETOUR = "Return Price ";
        var PRIXATTENTE = "Accompagnement price ";
        var NOMBREHEURES = "Number of hours ";
        var PRIXPARHEURE = "Price per hour ";
        var PRIXTOTAL = "Total Price ";
        var lang = "en";
        var RECAPTITLE = "Show Summary : ";
        var PERSONALHEAD = "Reservation ";
        var isParis = true;
        var FUEL = 0.05;

        // var SESSIONACTIVE = "";
    </script>
    <div class="gototop js-top"><a href="#" class="js-gotop" title="Return to the top of the page"><i class="icon-arrow-up"></i></a></div>
    <script src="https://www.allomycab.ma/js/magnific-popup-options.js" defer></script>
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js" defer></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAtjCvysmjGGyqPhy6uARmErczhpm2btc0&libraries=places,geometry&region=MA" defer></script>
    <script src="https://www.allomycab.ma/js/datepicker-en.js" defer></script>
    <script src="https://www.allomycab.ma/js/gallery.js" defer></script>
    <script src="https://www.allomycab.ma/js/main.js" defer></script>
</body>

</html><?php /**PATH C:\laragon\www\orchid-project\resources\views/liding.blade.php ENDPATH**/ ?>