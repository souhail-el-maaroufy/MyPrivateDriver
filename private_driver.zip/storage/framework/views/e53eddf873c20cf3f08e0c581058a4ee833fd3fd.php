

<?php $__env->startSection('title', 'Reservation'); ?>
<?php $__env->startSection('description', 'Reservation Edit'); ?>

<?php $__env->startSection('navbar'); ?>
    <div class="text-center">
        <a href="<?php echo e(route('platform.reservation.list')); ?>">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="my-5 py-5 bg-white">
        <h2 class="text-center"> Edit Reservation</h2>
        <div class="row m-3">
            <div class="col m-3 py-2 border-bottom border-primary border-1">
                <label class="fs-5">Full name : </label><span class="fs-5"> <?php echo e($reservation->full_name); ?></span>
            </div>
            <div class="col m-3 py-2 border-bottom border-primary border-1">
                <label class="fs-5">Number Place : </label><span class="fs-5"> <?php echo e($reservation->nb_place); ?></span>
            </div>
        </div>
        <div class="row m-3">
            <div class="col m-3 py-2 border-bottom border-primary border-1">
                <label class="fs-5">Number Phone : </label><span class="fs-5"> <?php echo e($reservation->phone); ?></span>
            </div>
            <div class="col m-3 py-2 border-bottom border-primary border-1">
                <label class="fs-5">Email : </label><span class="fs-5"> <?php echo e($reservation->email); ?></span>
            </div>
        </div>
        <?php $__currentLoopData = $reservation_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row m-3">
                <div class="col m-3 py-2 border-bottom border-primary border-1">
                    <label class="fs-5">Type : </label><span class="fs-5"> <?php echo e($item->type); ?></span>
                </div>
                <div class="col m-3 py-2 border-bottom border-primary border-1">
                    <label class="fs-5">Depart : </label><span class="fs-5"> <?php echo e($item->depart); ?></span>
                </div>
                <div class="col m-3 py-2 border-bottom border-primary border-1">
                    <label class="fs-5">Destination : </label><span class="fs-5"> <?php echo e($item->destination); ?></span>
                </div>
            </div>

            <div class="row m-3">
                <div class="col m-3 py-2 border-bottom border-primary border-1">
                    <label class="fs-5">Created_at : </label><span class="fs-5"> <?php echo e($reservation->created_at); ?></span>
                </div>
                <div class="col m-3 py-2 border-bottom border-primary border-1">
                    <label class="fs-5">Date reservation : </label><span class="fs-5">
                        <?php echo e($item->date_reservation); ?></span>
                </div>
                <div class="col m-3 py-2 border-bottom border-primary border-1">
                    <label class="fs-5">Time reservation : </label><span class="fs-5">
                        <?php echo e($item->hours . ' h ' . $item->minutes . ' min'); ?></span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row m-4">
            <div class="col m-3 py-2 border-bottom border-primary border-1">
                <label class="fs-5">Details : </label><br>
                <span class="fs-5"><?php echo e($reservation->details . ' fghfdhghfhgfhdfsdsgsgfdgfhgjhkghkjhkdfggdsdfsfdsfeer'); ?></span>
            </div>
        </div>
        <div class="row m-4">
            <form action="<?php echo e(route('platform.reservation.confirmation',$reservation->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col  m-3 py-2">
                    <label class="fs-5">Status : </label>
                    <select name="status" class="form-select" aria-label="Default select example">
                        <?php $__currentLoopData = $reservation_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->value); ?>"><?php echo e($status->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col m-3 py-2 float-end">
                    <button class="btn btn-dark">save</button>
                </div>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('platform::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MyPrivateDriver\resources\views/back/reservation/Edit_reservation.blade.php ENDPATH**/ ?>