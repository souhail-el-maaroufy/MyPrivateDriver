<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH C:\laragon\www\orchid-project\vendor\orchid\platform\resources\views/partials/notification-wrap.blade.php ENDPATH**/ ?>