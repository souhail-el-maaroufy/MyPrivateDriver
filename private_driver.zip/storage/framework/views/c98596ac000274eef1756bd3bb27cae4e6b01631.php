<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <textarea <?php echo e($attributes); ?>><?php echo e($value ?? ''); ?></textarea>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\MyPrivateDriver\vendor\orchid\platform\resources\views/fields/textarea.blade.php ENDPATH**/ ?>