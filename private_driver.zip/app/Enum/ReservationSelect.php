<?php

namespace App\Enum;

enum  ReservationSelect:string
{
    case Confirm = "confirm";
    case Annuler = "annuler";
}